# EightQueensLab

Лабораторная работа: представление задачи и поиск в пространстве состояний.  
**Вариант 3:** задача о 8 ферзях.

Реализовано:
- DFS, BFS
- A* с эвристикой (forward checking)
- Обратный поиск
- Смешанная стратегия
- Экспорт графа переходов в Graphviz DOT

## Как открыть в IDE

### IntelliJ IDEA / Android Studio
1. **File → Open** → выберите папку `EightQueensLab-IDE`
2. IDEA автоматически подхватит Maven-проект
3. Дождитесь индексации → справа кнопка **Run** у метода `main`

### VS Code
1. Откройте папку `EightQueensLab-IDE`
2. Установите расширение **Extension Pack for Java** (Microsoft)
3. VS Code предложит импортировать Maven-проект → согласитесь
4. Запуск: `F5` или кнопка Run над `main`

### Eclipse
1. **File → Import → Existing Maven Projects**
2. Укажите папку `EightQueensLab-IDE`
3. Finish → Run As → Java Application

### NetBeans
1. **File → Open Project** → выберите папку
2. Run Project (F6)

## Запуск из терминала (Maven)

```bash
# Компиляция + запуск
mvn -q compile exec:java

# Или собрать jar
mvn -q package
java -jar target/eight-queens-lab-1.0-SNAPSHOT.jar
```

## Запуск без Maven (чистый javac)

```bash
mkdir -p out
javac -encoding UTF-8 -d out src/main/java/EightQueensLab.java
java -cp out EightQueensLab
```

После запуска в текущей папке появится `state_graph.dot`.  
Картинку: `dot -Tpng state_graph.dot -o state_graph.png`

## Структура проекта

```
EightQueensLab-IDE/
├── pom.xml                          # Maven (для удобного импорта в IDE)
├── README.md
└── src/main/java/
    └── EightQueensLab.java          # весь код в одном файле
```

Требования: **JDK 11+** (используется `String.repeat`).
