import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

/**
 * Лабораторная работа: Представление задачи и поиск в пространстве состояний.
 * Вариант 3: Задача о 8 ферзях (расставить 8 ферзей так, чтобы они не били друг друга).
 */
public class EightQueensLab {

    public static final int N = 8;

    // =========================================================================
    // 1. КОДИРОВАНИЕ СОСТОЯНИЙ (Кортеж позиций ферзей по столбцам)
    // =========================================================================

    /**
     * Неизменяемый класс состояния s = (q_1, q_2, ..., q_k),
     * где индекс массива соответствует столбцу (1..k), а значение — строке (1..8).
     */
    public static final class State {
        private final int[] queens;
        private final int hash;

        public State() {
            this.queens = new int[0];
            this.hash = Arrays.hashCode(this.queens);
        }

        public State(int... queens) {
            this.queens = Arrays.copyOf(queens, queens.length);
            this.hash = Arrays.hashCode(this.queens);
        }

        public int size() {
            return queens.length;
        }

        public int getRow(int colIndexZeroBased) {
            return queens[colIndexZeroBased];
        }

        /** Создаёт новое состояние путём добавления ферзя в следующий столбец на строку newRow */
        public State append(int newRow) {
            int[] next = Arrays.copyOf(queens, queens.length + 1);
            next[queens.length] = newRow;
            return new State(next);
        }

        /** Создаёт предыдущее состояние путём удаления ферзя из последнего столбца (для обратного поиска) */
        public State removeLast() {
            if (queens.length == 0) {
                throw new IllegalStateException("Невозможно удалить ферзя из пустого состояния S_0");
            }
            return new State(Arrays.copyOf(queens, queens.length - 1));
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof State)) return false;
            State other = (State) o;
            return Arrays.equals(this.queens, other.queens);
        }

        @Override
        public int hashCode() {
            return hash;
        }

        @Override
        public String toString() {
            if (queens.length == 0) return "()";
            StringBuilder sb = new StringBuilder("(");
            for (int i = 0; i < queens.length; i++) {
                sb.append(queens[i]);
                if (i < queens.length - 1) sb.append(", ");
            }
            sb.append(")");
            return sb.toString();
        }
    }

    // =========================================================================
    // 2. РЕАЛИЗАЦИЯ МОДЕЛИ ПРОСТРАНСТВА СОСТОЯНИЙ И ГРАФА ПЕРЕХОДОВ
    // =========================================================================

    /**
     * Программное представление графа пространства состояний G = (V, E),
     * где вершины V — состояния, а направленные рёбра E — допустимые переходы.
     */
    public static class StateGraph {
        private final Map<State, List<State>> adjacencyList = new LinkedHashMap<>();

        public void addEdge(State from, State to) {
            adjacencyList.computeIfAbsent(from, k -> new ArrayList<>());
            adjacencyList.computeIfAbsent(to, k -> new ArrayList<>());
            if (!adjacencyList.get(from).contains(to)) {
                adjacencyList.get(from).add(to);
            }
        }

        public Map<State, List<State>> getAdjacencyList() {
            return adjacencyList;
        }

        public int vertexCount() {
            return adjacencyList.size();
        }

        public int edgeCount() {
            return adjacencyList.values().stream().mapToInt(List::size).sum();
        }
    }

    /**
     * Пункт 1.3 и 2.3: Проверка корректности перехода (Safe(s, newRow)).
     * Проверяет, не бьёт ли новый ферзь в столбце (k + 1) на строке newRow ранее выставленных ферзей.
     */
    public static boolean isValidTransition(State state, int newRow) {
        if (newRow < 1 || newRow > N) return false;
        int newCol = state.size() + 1;
        if (newCol > N) return false;

        for (int i = 0; i < state.size(); i++) {
            int col = i + 1;
            int row = state.getRow(i);
            // Конфликт по горизонтали или по диагонали
            if (row == newRow || Math.abs(row - newRow) == Math.abs(col - newCol)) {
                return false;
            }
        }
        return true;
    }

    /** Пункт 1.4 и 2.3: Полная проверка допустимости состояния */
    public static boolean isValidState(State state) {
        if (state.size() > N) return false;
        for (int i = 0; i < state.size(); i++) {
            int r1 = state.getRow(i);
            if (r1 < 1 || r1 > N) return false;
            for (int j = i + 1; j < state.size(); j++) {
                int r2 = state.getRow(j);
                if (r1 == r2 || Math.abs(r1 - r2) == (j - i)) {
                    return false;
                }
            }
        }
        return true;
    }

    /** Пункт 2.2: Генерация всех возможных допустимых переходов R(s) */
    public static List<State> getSuccessors(State state) {
        List<State> successors = new ArrayList<>();
        if (state.size() >= N) return successors;

        for (int r = 1; r <= N; r++) {
            if (isValidTransition(state, r)) {
                successors.add(state.append(r));
            }
        }
        return successors;
    }

    /** Пункт 2.2: Проверка достижения целевого состояния S_G */
    public static boolean isGoal(State state) {
        return state.size() == N && isValidState(state);
    }

    /** Пункт 2.2: Функция стоимости перехода C(s, s') */
    public static int transitionCost(State from, State to) {
        return 1;
    }

    /** Восстановление пути от S_0 до S_G по словарю предков */
    private static List<State> reconstructPath(Map<State, State> parentMap, State goal) {
        LinkedList<State> path = new LinkedList<>();
        State curr = goal;
        while (curr != null) {
            path.addFirst(curr);
            curr = parentMap.get(curr);
        }
        return path;
    }

    /** Контейнер результатов работы алгоритма поиска */
    public static class SearchResult {
        public final String strategyName;
        public final State goalState;
        public final List<State> path;
        public final int visitedCount;
        public final double timeMs;
        public final int maxMemoryNodes;

        public SearchResult(String strategyName, State goalState, List<State> path,
                            int visitedCount, double timeMs, int maxMemoryNodes) {
            this.strategyName = strategyName;
            this.goalState = goalState;
            this.path = path;
            this.visitedCount = visitedCount;
            this.timeMs = timeMs;
            this.maxMemoryNodes = maxMemoryNodes;
        }
    }

    // =========================================================================
    // 3. СТРАТЕГИЯ 1: СЛЕПОЙ ПОИСК (DFS и BFS)
    // =========================================================================

    /** Поиск в глубину (DFS) с контролем посещённых состояний (защита от зацикливания) */
    public static SearchResult dfsSearch(State startState) {
        long t0 = System.nanoTime();
        Deque<State> stack = new ArrayDeque<>();
        Set<State> visited = new HashSet<>();
        Map<State, State> parent = new HashMap<>();

        stack.push(startState);
        parent.put(startState, null);
        int maxMemory = 1;

        while (!stack.isEmpty()) {
            maxMemory = Math.max(maxMemory, stack.size());
            State s = stack.pop();

            if (visited.contains(s)) continue;
            visited.add(s);

            if (isGoal(s)) {
                double dt = (System.nanoTime() - t0) / 1_000_000.0;
                return new SearchResult("Поиск в глубину (DFS)", s,
                        reconstructPath(parent, s), visited.size(), dt, maxMemory);
            }

            List<State> successors = getSuccessors(s);
            // В обратном порядке, чтобы вершина стека соответствовала меньшей строке r
            for (int i = successors.size() - 1; i >= 0; i--) {
                State next = successors.get(i);
                if (!visited.contains(next)) {
                    parent.put(next, s);
                    stack.push(next);
                }
            }
        }
        return new SearchResult("Поиск в глубину (DFS)", null, Collections.emptyList(), visited.size(), 0, maxMemory);
    }

    /** Поиск в ширину (BFS) */
    public static SearchResult bfsSearch(State startState) {
        long t0 = System.nanoTime();
        Queue<State> queue = new ArrayDeque<>();
        Set<State> visited = new HashSet<>();
        Map<State, State> parent = new HashMap<>();

        queue.add(startState);
        visited.add(startState);
        parent.put(startState, null);
        int maxMemory = 1;

        while (!queue.isEmpty()) {
            maxMemory = Math.max(maxMemory, queue.size());
            State s = queue.poll();

            if (isGoal(s)) {
                double dt = (System.nanoTime() - t0) / 1_000_000.0;
                return new SearchResult("Поиск в ширину (BFS)", s,
                        reconstructPath(parent, s), visited.size(), dt, maxMemory);
            }

            for (State next : getSuccessors(s)) {
                if (!visited.contains(next)) {
                    visited.add(next);
                    parent.put(next, s);
                    queue.add(next);
                }
            }
        }
        return new SearchResult("Поиск в ширину (BFS)", null, Collections.emptyList(), visited.size(), 0, maxMemory);
    }

    // =========================================================================
    // 4. ВВЕДЕНИЕ ЭВРИСТИЧЕСКОЙ ФУНКЦИИ И ЭВРИСТИЧЕСКИЙ ПОИСК (A* и Жадный)
    // =========================================================================

    /**
     * Пункт 4.1: Эвристическая функция h(s).
     * Оценивает количество оставшихся шагов (8 - k) с учётом числа атакованных
     * клеток в незаполненных столбцах и проверки вперёд (Forward Checking).
     * Если в каком-либо будущем столбце не осталось допустимых клеток, возвращает +Infinity.
     */
    public static double heuristic(State state) {
        int k = state.size();
        if (k == N) return 0.0;

        int remainingCols = N - k;
        int totalFreeCells = 0;

        for (int futureCol = k + 1; futureCol <= N; futureCol++) {
            int colFree = 0;
            for (int r = 1; r <= N; r++) {
                boolean safe = true;
                for (int i = 0; i < k; i++) {
                    int qCol = i + 1;
                    int qRow = state.getRow(i);
                    if (qRow == r || Math.abs(qRow - r) == (futureCol - qCol)) {
                        safe = false;
                        break;
                    }
                }
                if (safe) colFree++;
            }
            // Forward Checking: если будущий столбец полностью заблокирован — тупик
            if (colFree == 0) {
                return Double.POSITIVE_INFINITY;
            }
            totalFreeCells += colFree;
        }

        int maxPossibleCells = remainingCols * N;
        int attackedCells = maxPossibleCells - totalFreeCells;

        // Допустимая эвристика h(s) <= 8 - k, поощряющая продвижение вглубь и минимум блокировок
        return (remainingCols - k * 0.05) + (attackedCells / 1000.0);
    }

    /** Узел приоритетной очереди для алгоритма A* */
    private static class Node implements Comparable<Node> {
        final State state;
        final double f;

        Node(State state, double f) {
            this.state = state;
            this.f = f;
        }

        @Override
        public int compareTo(Node other) {
            int cmp = Double.compare(this.f, other.f);
            if (cmp != 0) return cmp;
            // При равных f предпочитаем более глубокое состояние
            return Integer.compare(other.state.size(), this.state.size());
        }
    }

    /** Пункт 3 и 4.2: Алгоритм эвристического поиска A* (f(s) = g(s) + h(s)) */
    public static SearchResult aStarSearch(State startState) {
        long t0 = System.nanoTime();
        PriorityQueue<Node> openSet = new PriorityQueue<>();
        Map<State, Integer> gScore = new HashMap<>();
        Map<State, State> parent = new HashMap<>();
        Set<State> visited = new HashSet<>();

        int startG = startState.size();
        gScore.put(startState, startG);
        parent.put(startState, null);
        openSet.add(new Node(startState, startG + heuristic(startState)));
        int maxMemory = 1;

        while (!openSet.isEmpty()) {
            maxMemory = Math.max(maxMemory, openSet.size());
            Node current = openSet.poll();
            State s = current.state;

            if (visited.contains(s)) continue;
            visited.add(s);

            if (isGoal(s)) {
                double dt = (System.nanoTime() - t0) / 1_000_000.0;
                return new SearchResult("Эвристический поиск (A*)", s,
                        reconstructPath(parent, s), visited.size(), dt, maxMemory);
            }

            for (State next : getSuccessors(s)) {
                if (visited.contains(next)) continue;
                double hVal = heuristic(next);
                if (Double.isInfinite(hVal)) continue; // Отсечение заведомо тупиковых ветвей

                int tentativeG = gScore.get(s) + transitionCost(s, next);
                if (tentativeG < gScore.getOrDefault(next, Integer.MAX_VALUE)) {
                    gScore.put(next, tentativeG);
                    parent.put(next, s);
                    openSet.add(new Node(next, tentativeG + hVal));
                }
            }
        }
        return new SearchResult("Эвристический поиск (A*)", null, Collections.emptyList(), visited.size(), 0, maxMemory);
    }

    // =========================================================================
    // 6. ИССЛЕДОВАТЕЛЬСКАЯ ЧАСТЬ (Обратный поиск, Смешанная стратегия, Граф)
    // =========================================================================

    /**
     * Пункт 6.1: Обратный поиск — от целевого состояния S_G к начальному S_0.
     * Обратный оператор удаляет ферзя из последнего заполненного столбца.
     */
    public static SearchResult backwardSearch(State goalState, State startState) {
        long t0 = System.nanoTime();
        List<State> path = new ArrayList<>();
        Set<State> visited = new LinkedHashSet<>();

        State curr = goalState;
        path.add(curr);
        visited.add(curr);

        while (!curr.equals(startState)) {
            if (!isValidState(curr) || curr.size() == 0) {
                throw new IllegalStateException("Обнаружено недопустимое состояние при обратном поиске: " + curr);
            }
            curr = curr.removeLast();
            visited.add(curr);
            path.add(curr);
        }

        double dt = (System.nanoTime() - t0) / 1_000_000.0;
        return new SearchResult("Обратный поиск (S_G -> S_0)", startState, path, visited.size(), dt, 1);
    }

    /**
     * Пункт 6.2: Смешанная стратегия.
     * Комбинирует прямое аналитическое правило расстановки "ходом коня" (q_i = 2*i)
     * для подпространства первых 4 столбцов и алгоритм поиска A* для столбцов 5..8.
     */
    public static SearchResult mixedStrategySearch() {
        long t0 = System.nanoTime();
        List<State> directPrefix = new ArrayList<>();
        State current = new State();
        directPrefix.add(current);

        // Фаза 1: Прямой метод для первых 4 столбцов -> (2, 4, 6, 8)
        for (int col = 1; col <= 4; col++) {
            current = current.append(2 * col);
            directPrefix.add(current);
        }

        // Фаза 2: Поисковый метод (A*) из промежуточного состояния (2, 4, 6, 8)
        SearchResult aStarSubResult = aStarSearch(current);

        List<State> fullPath = new ArrayList<>(directPrefix.subList(0, directPrefix.size() - 1));
        fullPath.addAll(aStarSubResult.path);

        double dt = (System.nanoTime() - t0) / 1_000_000.0;
        return new SearchResult("Смешанная стратегия (Прямое правило + A*)",
                aStarSubResult.goalState, fullPath,
                aStarSubResult.visitedCount, dt, aStarSubResult.maxMemoryNodes);
    }

    /**
     * Пункт 6.3: Построение графа переходов по найденным траекториям и экспорт в формат Graphviz DOT.
     */
    public static StateGraph buildAndExportGraph(Map<String, List<State>> paths, String dotFilename) {
        StateGraph graph = new StateGraph();

        for (List<State> path : paths.values()) {
            for (int i = 0; i < path.size() - 1; i++) {
                graph.addEdge(path.get(i), path.get(i + 1));
            }
            // Добавляем смежные ветви на первых ярусах для демонстрации ветвления
            for (int i = 0; i < Math.min(2, path.size()); i++) {
                State s = path.get(i);
                for (State succ : getSuccessors(s)) {
                    graph.addEdge(s, succ);
                }
            }
        }

        try (PrintWriter out = new PrintWriter(new FileWriter(dotFilename))) {
            out.println("digraph StateSpace {");
            out.println("    rankdir=LR;");
            out.println("    node [shape=box, style=\"rounded,filled\", fillcolor=\"#EFEFEF\", fontname=\"Arial\"];");

            Set<State> solutionNodes = new HashSet<>();
            for (List<State> p : paths.values()) solutionNodes.addAll(p);

            for (State v : graph.getAdjacencyList().keySet()) {
                if (isGoal(v)) {
                    out.printf("    \"%s\" [fillcolor=\"#90EE90\", penwidth=2];%n", v);
                } else if (solutionNodes.contains(v)) {
                    out.printf("    \"%s\" [fillcolor=\"#D0E8FF\"];%n", v);
                }
            }

            for (Map.Entry<State, List<State>> entry : graph.getAdjacencyList().entrySet()) {
                for (State target : entry.getValue()) {
                    out.printf("    \"%s\" -> \"%s\";%n", entry.getKey(), target);
                }
            }
            out.println("}");
            System.out.println("[Граф] Файл графа переходов успешно сохранён в '" + dotFilename + "'.");
        } catch (IOException e) {
            System.err.println("Ошибка при сохранении DOT-файла: " + e.getMessage());
        }

        return graph;
    }

    // =========================================================================
    // ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ВЫВОДА
    // =========================================================================

    public static void printBoard(State state) {
        System.out.println("  a b c d e f g h");
        for (int r = N; r >= 1; r--) {
            StringBuilder rowStr = new StringBuilder(r + " ");
            for (int c = 1; c <= N; c++) {
                if (c <= state.size() && state.getRow(c - 1) == r) {
                    rowStr.append("Q ");
                } else {
                    rowStr.append(". ");
                }
            }
            rowStr.append(r);
            System.out.println(rowStr);
        }
        System.out.println("  a b c d e f g h");
    }

    public static void printPath(SearchResult res) {
        System.out.println("=== " + res.strategyName + " ===");
        System.out.println("Целевое состояние: " + res.goalState);
        System.out.printf("Посещено узлов: %d | Время: %.3f мс | Пик памяти (узлов): %d%n",
                res.visitedCount, res.timeMs, res.maxMemoryNodes);
        System.out.println("Последовательность состояний:");
        for (int i = 0; i < res.path.size(); i++) {
            System.out.printf("  Шаг %d: %s%n", i, res.path.get(i));
        }
        System.out.println();
    }

    public static void main(String[] args) {
        State start = new State();

        // Пункт 3 и 4: Запуск основных стратегий поиска
        SearchResult dfsRes = dfsSearch(start);
        SearchResult bfsRes = bfsSearch(start);
        SearchResult aStarRes = aStarSearch(start);

        printPath(dfsRes);
        printPath(bfsRes);
        printPath(aStarRes);

        // Пункт 5: Сравнительная таблица стратегий
        System.out.println("=== 5. АНАЛИЗ СТРАТЕГИЙ ===");
        System.out.printf("%-30s | %-20s | %-20s | %-22s%n",
                "Параметр", "Поиск в глубину", "Поиск в ширину", "Эвристический (A*)");
        System.out.println("-".repeat(100));
        System.out.printf("%-30s | %-20s | %-20s | %-22s%n",
                "Время выполнения",
                String.format("%.3f мс", dfsRes.timeMs),
                String.format("%.3f мс", bfsRes.timeMs),
                String.format("%.3f мс", aStarRes.timeMs));
        System.out.printf("%-30s | %-20d | %-20d | %-22d%n",
                "Количество посещённых узлов",
                dfsRes.visitedCount, bfsRes.visitedCount, aStarRes.visitedCount);
        System.out.printf("%-30s | %-20s | %-20s | %-22s%n",
                "Оптимальность решения", "Да (8 шагов)", "Да (8 шагов)", "Да (8 шагов)");
        System.out.printf("%-30s | %-20s | %-20s | %-22s%n%n",
                "Использование памяти (узлов)",
                dfsRes.maxMemoryNodes + " (низкое)",
                bfsRes.maxMemoryNodes + " (высокое)",
                aStarRes.maxMemoryNodes + " (низкое)");

        // Пункт 6: Исследовательская часть
        SearchResult backwardRes = backwardSearch(aStarRes.goalState, start);
        printPath(backwardRes);

        SearchResult mixedRes = mixedStrategySearch();
        printPath(mixedRes);

        System.out.println("Шахматная доска для решения, найденного смешанной стратегией " + mixedRes.goalState + ":");
        printBoard(mixedRes.goalState);

        // Построение и экспорт графа переходов
        Map<String, List<State>> pathsForGraph = new LinkedHashMap<>();
        pathsForGraph.put("DFS", dfsRes.path);
        pathsForGraph.put("A*", aStarRes.path);
        pathsForGraph.put("Mixed", mixedRes.path);

        StateGraph graph = buildAndExportGraph(pathsForGraph, "state_graph.dot");
        System.out.printf("[Граф] Построен подграф переходов: вершин = %d, рёбер = %d.%n",
                graph.vertexCount(), graph.edgeCount());
    }
}
